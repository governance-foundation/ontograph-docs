# Research technical note

Governing issue: [#2782](https://github.com/governance-foundation/ontograph/issues/2782), within epic #2774. This six-page review candidate accompanies the independently reproducible research package. Publication remains a separate operator decision.

`technical-note.pdf` is built from the exact actual five-case RD-4 results identified in `technical-note.metadata.json`. Source proposals and actual observations remain distinct. The note also summarises the separately retained general OWL exchange and pinned nine-example evidence; it grants no canonical adoption or C0-C7 credit.

## Rebuild

Use Python with ReportLab 4.4.9 and pypdf 6.10.0. Supply the retained organisational `results.json` from the research package (or the matching repository acceptance evidence):

```text
python -B build_note.py --results PATH/TO/results.json --output technical-note.pdf
```

The builder requires five actual cases, matching repeat evidence and the recorded entailment observations. It rejects any output other than six pages. PDF generation is deterministic with the declared inputs and tool versions. Rebuilding writes metadata with visual review pending; a successful build does not establish visual acceptance.

## Visual acceptance

All six pages of the retained PDF were rendered with Poppler at 1400-pixel long edge and inspected individually. Text, tables, diagrams and footers are readable, contained and unclipped; six intended page boundaries are preserved. `visual-review.json` binds this inspection to the PDF and rendered page hashes. Rendered images are session-owned review evidence, outside the public package.

The PDF uses built-in Helvetica and Times fonts and vector diagrams; no external font/image assets are required. Scholarly source attribution and license limitations appear in the note. Project code and newly authored material have no declared general reuse grant.
