"""Build the six-page research note from exact actual RD-4 observations (RDR-011)."""
import argparse
import hashlib
import json
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Flowable
from pypdf import PdfReader

INK = colors.HexColor('#173b34')
ACCENT = colors.HexColor('#b64c31')
MUTED = colors.HexColor('#516b66')
RULE = colors.HexColor('#d4ded8')
PALE = colors.HexColor('#f1f5f1')
WIDTH = A4[0] - 40 * mm


class Diagram(Flowable):
    def __init__(self, kind):
        Flowable.__init__(self)
        self.width = WIDTH
        self.height = 122 if kind == 'architecture' else 170
        self.kind = kind

    def draw(self):
        c = self.canv
        c.setStrokeColor(RULE)
        c.setFillColor(PALE)
        c.roundRect(0, 0, self.width, self.height, 5, stroke=1, fill=1)
        c.setStrokeColor(INK)
        def box(x, y, w, title, subtitle):
            c.setFillColor(colors.white)
            c.roundRect(x, y, w, 44, 3, fill=1, stroke=1)
            c.setFillColor(INK)
            c.setFont('Helvetica-Bold', 10)
            c.drawCentredString(x + w / 2, y + 27, title)
            c.setFont('Helvetica', 8)
            c.drawCentredString(x + w / 2, y + 12, subtitle)
        if self.kind == 'architecture':
            box(13, 42, 122, 'Source commitments', 'model + separately supplied facts')
            box(166, 42, 145, 'OntoGraph representation', 'candidate + provenance + gaps')
            box(342, 42, 112, 'Purpose-specific views', 'organisational / OWL / gUFO')
            for x1, x2 in ((136, 162), (312, 338)):
                c.line(x1, 64, x2, 64)
                c.line(x2 - 5, 68, x2, 64)
                c.line(x2 - 5, 60, x2, 64)
            c.setFont('Helvetica', 8)
            c.setFillColor(MUTED)
            c.drawString(15, 18, 'Arrows describe the bounded journey. No step grants canonical acceptance or normative authority.')
        else:
            box(20, 94, 108, 'Person', 'Kind')
            box(180, 94, 108, 'Appointment', 'Relator')
            box(340, 94, 108, 'Organization', 'Kind')
            box(20, 20, 108, 'Researcher', 'Role; specializes Person')
            for x1, x2 in ((128, 180), (288, 340)):
                c.line(x1, 116, x2, 116)
            c.setFont('Helvetica', 8)
            c.setFillColor(INK)
            c.drawCentredString(154, 139, 'mediation')
            c.drawCentredString(314, 139, 'mediation')
            c.drawCentredString(140, 104, '1..*')
            c.drawCentredString(170, 104, '0..*')
            c.drawCentredString(300, 104, '0..*')
            c.drawCentredString(330, 104, '1..*')
            c.line(74, 64, 74, 84)
            p = c.beginPath()
            p.moveTo(68, 84); p.lineTo(80, 84); p.lineTo(74, 94); p.close()
            c.setFillColor(colors.white); c.drawPath(p, fill=1, stroke=1)
            c.setFillColor(MUTED)
            c.setFont('Helvetica', 8)
            c.drawString(152, 50, 'Separate source relation IDs; two independent minima.')
            c.drawString(152, 36, 'Hollow triangle: specialization. Neither mediation is exact-one.')
            c.drawString(152, 22, 'Supporting Quality and Event facts remain in the full source dossier.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', required=True, type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('technical-note.pdf'))
    a = parser.parse_args()
    result_bytes = a.results.read_bytes()
    result = json.loads(result_bytes)
    if result.get('mode') != 'actual' or len(result['cases']) != 5 or not result['repeatEqual']:
        raise ValueError('Note requires the completed five-case actual result, with repeated agreement.')
    if not all('entailments' in case for case in result['cases']):
        raise ValueError('Note requires actual positive/forbidden entailment observations.')
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='BodyNote', fontName='Helvetica', fontSize=9.4, leading=14.3,
                              textColor=INK, spaceAfter=8))
    styles.add(ParagraphStyle(name='SmallNote', fontName='Helvetica', fontSize=7.8, leading=11.5,
                              textColor=MUTED, spaceAfter=6))
    styles.add(ParagraphStyle(name='TitleNote', fontName='Times-Roman', fontSize=38, leading=42,
                              textColor=INK, spaceAfter=17))
    styles.add(ParagraphStyle(name='HeadingNote', fontName='Times-Roman', fontSize=25, leading=29,
                              textColor=INK, spaceAfter=12))
    styles.add(ParagraphStyle(name='SubNote', fontName='Helvetica-Bold', fontSize=10.5, leading=15,
                              textColor=INK, spaceBefore=8, spaceAfter=6))
    styles.add(ParagraphStyle(name='Eyebrow', fontName='Helvetica-Bold', fontSize=8, leading=11,
                              textColor=ACCENT, spaceAfter=14))
    story = []
    def p(text, style='BodyNote'):
        story.append(Paragraph(text, styles[style]))
    def heading(number, title):
        p('ONTOGRAPH RESEARCH  /  ' + number, 'Eyebrow')
        p(title, 'HeadingNote')
    def table(headers, rows, widths):
        data = [[Paragraph(escape(str(v)), styles['SmallNote']) for v in row] for row in [headers, *rows]]
        t = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), PALE), ('LINEBELOW', (0, 0), (-1, 0), .8, INK),
                               ('LINEBELOW', (0, 1), (-1, -1), .4, RULE), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                               ('LEFTPADDING', (0, 0), (-1, -1), 7), ('RIGHTPADDING', (0, 0), (-1, -1), 7),
                               ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]))
        story.append(t); story.append(Spacer(1, 10))

    p('TECHNICAL NOTE  /  REVIEW CANDIDATE  /  9 OCTOBER 2026', 'Eyebrow')
    p('One conceptual model.<br/><font color="#b64c31"><i>Several useful views.</i></font>', 'TitleNote')
    p('An OntoUML-grounded organisational case, general OWL exchange and a distinct gUFO projection.', 'SubNote')
    p('<b>Research question.</b> Can different views retain connected conceptual identities without making the projection the limit of the model? This demonstration separates the rich canonical architecture from the bounded source-derived candidates that the current product actually produces.')
    p('The case connects people, an organisation, appointments and explicitly recorded research memberships. It distinguishes an enduring person from a contextual role, a relator from a bare link, and supplied interval evidence from a temporal conclusion inferred from a label.')
    story.append(Diagram('architecture')); story.append(Spacer(1, 12))
    p('<b>Contribution.</b> A traceable comparison of two different interoperability questions: preserving selected foreign OWL structure, and projecting explicit OntoUML-grounded commitments into gUFO-based OWL. Source pointers, generated identities, typed query answers and diagnostic observations remain inspectable.')
    p('<b>Claim classes.</b> Demonstrated claims bind actual input/output/runtime identities. Proposed architecture describes commitments beyond that evidence. Open questions identify unsettled interpretation or preservation obligations. Canonical adoption, normative staffing authority and comprehensive C0-C7 acceptance are not demonstrated.')
    p('The static package and bounded recorded explorer are separate deliverables. This note is a review candidate; approved publication and live download verification are separate acceptance steps.', 'SmallNote')
    story.append(PageBreak())

    heading('01', 'The conceptual case')
    p('Person and Organization are explicitly declared Kinds. Researcher is a Role specializing Person. Appointment is a Relator with separately identified person and organisation mediations. Each appointment is intended to have at least one class-correct participant on each relation; no exact-one commitment is introduced.')
    story.append(Diagram('case')); story.append(Spacer(1, 11))
    p('One person has two overlapping appointments with the same organisation. A second person shares the display label but has no declared research membership. Equal labels prove neither equality nor inequality. Two Mass qualities retain separate identity and bearer references despite equal decimal values with lexical forms 70.0 and 70.00. Both people have separately identified Seminar participation facts.')
    table(['Source distinction', 'What the view preserves', 'What it cannot establish'], [
        ['Person / Researcher', 'Identity separate from explicit role-membership records', 'Modal rigidity or necessary role nonmembership'],
        ['Appointment / mediation', 'Two appointment IDs and two independent participant relations', 'Rights, duties or valid organisational authority'],
        ['Quality / value', 'Quality IDs, bearer refs and typed decimal terms', 'Equal values as identical qualities'],
        ['Event / participation', 'Event identity and qualified participation facts', 'A bare attendance edge as the complete event account'],
    ], [105, 185, WIDTH - 290])
    p('<b>Time is supplied evidence.</b> The profile uses explicit half-open intervals [begin,end). At 10:30Z two membership records are active; at noon one remains. The appointment-link query still lists both recorded appointments at noon. It is an atemporal link query, not a staffing-authority decision.')
    p('<b>Validation gap.</b> Generated generic SHACL checks two total gufo:mediates values. It does not enforce a class-specific minimum independently for each source relation. The source oracle and generated qualified OWL restrictions are checked separately; a SHACL pass does not discharge conceptual correctness.', 'SmallNote')
    story.append(PageBreak())

    heading('02', 'Two interoperability questions')
    p('General OWL exchange', 'SubNote')
    p('A separate non-gUFO RDF/XML vocabulary contains named classes, subclassing, object properties, domain/range and an existential restriction. Four actual import/export operations preserve the independently declared 18-triple supported graph from a 22-triple source. Four restriction triples are explicitly omitted. Reexport is RDF-isomorphic and byte-identical to the first export.')
    p('The bridge remains foreign-source-only staging with a blocking interpretation gap and not-promoted status. It creates no accepted canonical assertions. A class called Researcher supplies no evidence of OntoUML anti-rigidity, dependence or role identity. Domain/range axioms support inference; they are not closed-world data constraints.')
    p('The original source bytes are retained separately by the research package. Unsupported-source preservation wording in the API is tracked as defect #2791; the stored bridge alone is not custody of the omitted restriction.', 'SmallNote')
    p('The gUFO-based organisational projection', 'SubNote')
    table(['Purpose', 'Retained meaning', 'Reduction / unresolved commitment'], [
        ['Conceptual inspection', 'Explicit Kind, Role, Relator, Quality and Event distinctions', 'Diagram agreement is not independent modal proof'],
        ['Organisational inspection', 'Connected person/organisation/appointment IDs; explicit intervals', 'Declared membership is not valid staffing or authority'],
        ['gUFO-based OWL', 'Named identities, mediation, quality bearers, qualified cardinalities', 'Full identity/rigidity/normativity is not established'],
        ['Qualified facts', 'Composition vocabulary for memberships and participation', 'Temporal meaning is not encoded using gUFO alone'],
        ['Foreign OWL bridge', 'Selected named RDF structure and explicit import gaps', 'Restrictions omitted; no canonical semantic lift'],
    ], [103, 185, WIDTH - 288])
    p('Source IDs connect the views. Generated IRIs are product projection identities, while canonicalRef remains null for the research candidate. Source, candidate, mapping, standards result and independent review remain different artifacts. No accepted enrichment, Decision or Promotion is fabricated.')
    p('OWL and gUFO are purpose-specific projections. Their expressivity does not define the canonical model\'s ceiling. Normative rights and duties remain proposed or open until explicit commitments and authority evidence are supplied.', 'SmallNote')
    story.append(PageBreak())

    heading('03', 'Actual operations and observations')
    p('Method: the installed pinned product imports the reviewed model and separately supplied instances; the runner checks actual source validation, generated OWL restrictions, staged readback, source-assisted reimport, graph isomorphism, typed SELECT answers, OWL reasoning, SHACL and nonmutation. Five scenarios execute twice against independently frozen expectations. Standards checks use offline pinned ontology/provider inputs.')
    rows = []
    for case in result['cases']:
        rows.append([case['id'], case['sourceOutcome'].replace('selected-constraints-satisfied', 'selected checks satisfied'),
                     str(len(case['activeRoleIds'])), str(len(case['answers']['organisationAppointments']['rows'])),
                     'conforms' if case['shacl']['conforms'] else 'nonconformant', 'consistent' if case['owlConsistent'] else 'inconsistent'])
    table(['Scenario', 'Source result', 'Active', 'Links', 'SHACL', 'OWL'], rows,
          [78, 124, 36, 34, 97, WIDTH - 369])
    p('The valid SELECT returns appointment:one and appointment:two, both linked to person:a and organization:one through their source-defined relations. The missing-grounding cases retain only one complete appointment binding. Typed URI/literal kinds, variable order, decimal datatypes and lexical terms are compared exactly before and after reload.')
    p('<b>Reasoning.</b> Actual OWL checks entail the supplied mediation conclusion. They do not entail a timeless Researcher class assertion for person:a or equality of the two qualities. Non-entailment is not proof of negation. Both missing-grounding cases remain OWL-consistent: an open-world interpretation can admit facts not explicitly recorded.')
    p('<b>Diagnostics.</b> Removing the first appointment\'s organisation participant yields CWA-invalid or OWA-unknown source validation and SHACL nonconformance. This diagnostic exposes incomplete finite recorded grounding; the unchanged explicit membership count cannot establish that the staffing relation is valid.')
    p('<b>Persistence.</b> Staged candidate readback, source-assisted reimport and selected query preservation are demonstrated. The concrete canonical data digest remains unchanged. This is not arbitrary target-only inversion, canonical adoption, a second-backend proof or a licence to promote the candidate.', 'SmallNote')
    story.append(PageBreak())

    heading('04', 'Supporting nine-example evidence')
    p('The appendix reuses a separate pinned direct-gUFO Turtle admission/regeneration suite. Its original two-run aggregate demonstrated all nine cases; a distinct fresh review subsequently reproduced all nine. This is supporting coverage, not the main narrative and not a general OntoUML JSON transformation.')
    table(['Pinned input', 'Assertions', 'OWL', 'Upstream semantic SHACL'], [
        ['Endurant types', 89, 'consistent', 'conforms'], ['Objects and parts', 153, 'consistent', 'conforms'],
        ['Qualities', 125, 'consistent', 'conforms'], ['Relators', 104, 'consistent', 'conforms'],
        ['Events', 89, 'consistent', 'conforms'], ['Situations', 137, 'consistent', 'conforms'],
        ['Higher-order types', 66, 'consistent', 'conforms'],
        ['Invalid endurant types', 20, 'consistent', '2 expected diagnostic rows'],
        ['Invalid higher-order types', 25, 'consistent', '5 expected diagnostic rows'],
    ], [152, 62, 76, WIDTH - 290])
    p('All 808 source assertions remain represented in typed candidates. Complete RDF isomorphism is checked without literal normalization. Generated source-coverage shapes and upstream semantic shapes are separate. The two invalid inputs retain their offending facts: detecting them is success of the diagnostic test, not conceptual endorsement.')
    p('Historical records remain immutable: individual author runs recorded 9/9 implemented, 0/9 fully demonstrated and 0/9 independently reviewed; the qualified two-run aggregate recorded 9/9 demonstrated and 0/9 reviewed; the successor supplies 9/9 independent review. The custody audit independently checks retained/public hashes, three archives and agreement of declared artifacts; it does not rerun the standards engine.')
    p('<b>Limits.</b> Neither nine examples nor a passing OWL/SHACL check establishes full gUFO/UFO/OntoUML coverage, modal identity/rigidity proof, target-only inversion, admission API parity, expert endorsement, comprehensive C0-C7 acceptance or a second backend. Compiled-input identity coverage remains partial.')
    p('Pinned corpus/ontology: f4122544133544eb4c6c467ba316302ab20b754a. Pinned gufoshapes: b95e14b034c93c42323e8beb8c08f697b026e553. Upstream sources are CC BY 4.0; project code/new data have no declared general reuse grant. Provider/runtime distribution is a separate prerequisite.', 'SmallNote')
    story.append(PageBreak())

    heading('05', 'Reproduction and research questions')
    p('Use the versioned download package in a fresh directory outside Git. Verify its complete checksum manifest before execution. Supply the exact complete installed OntoGraph package and pinned Java/OWL/Jena dependencies declared by the prerequisite manifest; the executable alone is insufficient because the runner verifies every installed package file.')
    p('The package journey runs the separate OWL exchange, the five-case organisational journey and the nine-source suite using only packaged inputs and declared prerequisites. Retain actual commands, exits, failures and outputs. Compare exact typed query answers and graph criteria, rather than treating a successful command or matching byte count as semantic preservation.')
    table(['Identity', 'Binding'], [
        ['Reviewed new source', 'a4d01ef7503ecba2b809bb7e03e3241f8c3a7123'],
        ['Installed runtime source', result['runtimeCommit']],
        ['Runtime executable', result['binarySha256']],
        ['Exact note result input', hashlib.sha256(result_bytes).hexdigest()],
    ], [116, WIDTH - 116])
    p('Focused feedback', 'SubNote')
    p('1. Which additional explicit commitments and evidence would make Appointment a defensible normative truthmaker for staffing rights and duties?<br/>2. Which counterexample separates successful graph preservation from preservation of identity, dependence or role meaning?<br/>3. What should an organisational view omit, and which provenance or gap records must remain reachable?<br/>4. Which class-specific mediation constraints must be enforced beyond the generic SHACL profile?<br/>5. What evidence would justify a stronger inverse or semantic-equivalence claim?')
    p('References and attribution', 'SubNote')
    p('[1] J. P. A. Almeida, G. Guizzardi, T. P. Sales, R. A. Falbo. <i>gUFO: A Lightweight Implementation of the Unified Foundational Ontology (UFO)</i>, 2019. <link href="https://nemo-ufes.github.io/gufo/" color="#173b34">Official gUFO documentation</link> (including the recommended attribution).<br/>[2] <link href="https://github.com/nemo-ufes/gufo/tree/f4122544133544eb4c6c467ba316302ab20b754a" color="#173b34">Pinned gUFO corpus and ontology</link>; <link href="https://github.com/nemo-ufes/gufoshapes/tree/b95e14b034c93c42323e8beb8c08f697b026e553" color="#173b34">pinned gufoshapes</link>, CC BY 4.0.<br/>[3] OntoGraph research contract RDR-001..020, reviewed source dossier, actual operation receipts and separate independent review records, retained in the accompanying package.', 'SmallNote')
    p('A complete package review and approved live publication are separate gates. This note does not grant operational or semantic authority. Source, verified package, accepted explorer and live publication are reported separately.', 'SmallNote')

    def decorate(canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(RULE); canvas.line(20 * mm, 17 * mm, A4[0] - 20 * mm, 17 * mm)
        canvas.setFillColor(MUTED); canvas.setFont('Helvetica', 7.5)
        canvas.drawString(20 * mm, 12 * mm, 'OntoGraph  /  Semantic viewpoints  /  Review candidate')
        canvas.drawRightString(A4[0] - 20 * mm, 12 * mm, f'{doc.page} / 6')
        canvas.restoreState()
    a.output.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(a.output), pagesize=A4, rightMargin=20 * mm, leftMargin=20 * mm,
                            topMargin=19 * mm, bottomMargin=24 * mm, title='One conceptual model, several useful views',
                            author='OntoGraph research demonstration', invariant=1)
    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    pages = PdfReader(a.output).pages
    if len(pages) != 6:
        raise ValueError(f'Expected six pages; rendered {len(pages)}. Inspect and repair layout.')
    metadata = dict(schemaVersion='ontograph.research.technical-note.v1', pages=6,
                    resultSha256=hashlib.sha256(result_bytes).hexdigest(),
                    pdfSha256=hashlib.sha256(a.output.read_bytes()).hexdigest(),
                    inputSourceCommit='a4d01ef7503ecba2b809bb7e03e3241f8c3a7123',
                    runtimeCommit=result['runtimeCommit'], visualReview='pending')
    a.output.with_suffix('.metadata.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    print(f'Built {len(pages)} pages; visual review required.')


if __name__ == '__main__':
    main()
