# Actual organisational source-to-gUFO journey

Issue #2779, epic #2774; RDR-003, RDR-004, RDR-006, RDR-007 and RDR-009.
The separately reviewed RD-2 model, instances and frozen expectations are inputs.
The installed product, rather than the renderer or supplied target triples,
produces the candidate report, RDF, shapes and readback.

## Observed results

| Scenario | Selected source outcome | Active explicit memberships | Complete appointment links | Generic SHACL | OWL |
| --- | --- | ---: | ---: | --- | --- |
| valid | selected constraints satisfied | 2 | 2 | conforms | consistent |
| missing-cwa | invalid | 2 | 1 | nonconformant | consistent |
| missing-owa | unknown | 2 | 1 | nonconformant | consistent |
| end-boundary | selected constraints satisfied | 1 | 2 | conforms | consistent |
| empty-role | selected constraints satisfied | 0 | 2 | conforms | consistent |

Five cases executed twice, all **140 actual operations** exited zero and matched
the independently frozen expectations. All **20** corresponding producer artifact
pairs are byte-identical. Source model, instances, schemas and concrete canonical
data remain unchanged. See [results](results.json), [verification](verification.json),
[portable command records](commands.json), [tool identities](tool-identities.json)
and the [checksum-bound evidence index](evidence-index.json).

The missing first organisation grounding produces `COMP-MISSING-MEDIATION` in
the actual source report. Its CWA-invalid and OWA-unknown results differ from OWL
consistency and generic SHACL nonconformance. The unchanged explicit membership
count is not evidence of valid staffing or organisational authority.

Three exact typed SELECT results are compared before/after staged reload:
appointment/person/organisation bindings, quality/bearer/decimal values and
qualified participation/person/event bindings. Variable order, URI/literal kinds,
datatype, language and decimal lexical forms are checked; matching labels are
not used to choose identities. The appointment query is atemporal. Explicit
half-open membership observations produce two active records at 10:30Z and one
at noon without inferring a timeless role assertion.

Actual offline OWL reasoning entails the supplied mediation conclusion and does
not entail the supplied timeless-Researcher or equal-qualities conclusions.
Non-entailment does not prove negation. OWL qualified restrictions preserve a
separate minimum one for each mediation and introduce no maximum/exact-one.
Generic SHACL still counts two total `gufo:mediates` values; it does not enforce
each relation's class-specific minimum. Conceptual correctness remains a
separate review obligation.

## Reproduce

Use the package journey supplied by RD-7, or invoke the
[runner](../../../../scripts/research-demonstration/organisation_reproduce.py)
with a fresh input/output pair and explicitly supplied installed prerequisites:

```text
python scripts/research-demonstration/organisation_reproduce.py --binary <full-installed-package/ontograph.exe> --inputs <input-root> --output <fresh-output> --java <java17> --tools <pinned-owl-tools> --jena-home <jena6.2.0> --jena-java <java21> --runtime-commit 1c3e2f7d4f1957cf6061b7f03386e3adaf9758e5 --repeats 2
```

All required fixtures, schemas, model, instances and expectations must be present
under input-root. RD-7 supplies a complete portable allowlist and fresh-directory
instructions. A single `--repeats 1` review executes the entire five-case journey;
two author passes establish the separately declared deterministic pairs.

The complete installed release manifest is verified, not only the executable.
Runtime source is `1c3e2f7d4f1957cf6061b7f03386e3adaf9758e5`; executable SHA-256
`688c5fc66d6b61963877fe5bd29324938f3cb03216eec58e0994137e0ee34a9d`.
The input source freeze is `a4d01ef7503ecba2b809bb7e03e3241f8c3a7123`.
The [executed runner](executed-runner.py) is byte-bound by verification.json.
Public commands alias only absolute process-root paths; semantic output remains
unchanged. Full host-specific process transcripts are retained internally and
their digest is recorded. Earlier limited calibration remains separately retained
and does not supply the final complete-oracle claim.

## Limits and independent acceptance

The representation is a source-derived staged candidate, not adopted canonical
assertions. Persistence means product readback/regeneration, RDF isomorphism and
selected exact query preservation; reimport requires original source. No arbitrary
target-only inverse, full modal identity/rigidity proof, normative authority,
API parity, second-backend qualification or C0-C7 credit is claimed.

Producer claims are [explicitly scoped and unreviewed](claims.json) until a
distinct independent receipt is retained by RD-8. Package reproduction, site/PDF
presentation, explorer acceptance and authorised publication remain separate.
New project-owned data/code have no declared general reuse grant; upstream and
provider licenses remain separately recorded. No restricted pilot was executed.
