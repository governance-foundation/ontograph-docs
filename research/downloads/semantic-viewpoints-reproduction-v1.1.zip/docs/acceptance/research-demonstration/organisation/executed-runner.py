"""Execute the bounded organisational journey with an explicitly supplied installed runtime.

RDR-003/004/006/007/009. This produces candidates, never adopted canonical facts.
All expectations come from the separately reviewed case, before execution.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
from urllib.parse import quote

import rdflib
from rdflib import Graph, OWL, RDFS, URIRef
from rdflib.compare import isomorphic

rdflib.NORMALIZE_LITERALS = False


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def inventory(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('binary', 'inputs', 'output', 'java', 'tools', 'jena-home', 'jena-java'):
        parser.add_argument('--' + key, required=True, type=Path)
    parser.add_argument('--runtime-commit', required=True)
    parser.add_argument('--repeats', type=int, choices=(1, 2), default=2)
    a = parser.parse_args()
    for key in ('binary', 'inputs', 'output', 'java', 'tools', 'jena_home', 'jena_java'):
        setattr(a, key, getattr(a, key).resolve())
    require(not a.output.exists(), 'Use a fresh output directory; retain earlier failures/results.')
    case_root = a.inputs / 'fixtures/research-demonstration/organisation'
    model = case_root / 'model.json'
    facts_path = case_root / 'instances.json'
    expected_path = case_root / 'expectations.json'
    expected = json.loads(expected_path.read_bytes())
    original_facts = json.loads(facts_path.read_bytes())
    for name, digest in expected['inputDigests'].items():
        require(sha(case_root / name) == digest, 'Frozen source digest differs: ' + name)
    package_path = a.binary.parent / 'release-manifest.json'
    package = json.loads(package_path.read_bytes())
    require(package['gitCommit'] == a.runtime_commit, 'Runtime manifest source identity differs.')
    require(a.binary.name in {p['path'] for p in package['files']}, 'Executable absent from package manifest.')
    for entry in package['files']:
        path = (a.binary.parent / entry['path']).resolve()
        require(path.is_relative_to(a.binary.parent), 'Manifest escapes runtime package.')
        require(path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256'].removeprefix('sha256:'),
                'Runtime package differs: ' + entry['path'])
    before = {name: inventory(a.inputs / name) for name in ('fixtures', 'schemas')}
    a.output.mkdir(parents=True)
    scratch = a.output / '.tmp/working'
    scratch.mkdir(parents=True)
    env = {key: value for key, value in os.environ.items() if key.upper() in ('SYSTEMROOT', 'WINDIR', 'USERPROFILE')}
    env.update(PATH=str(Path(os.environ['SystemRoot']) / 'System32'), TEMP=str(scratch), TMP=str(scratch),
               ONTOGRAPH_PROJECT_ROOT=str(a.inputs), ONTOGRAPH_INPUT_BASE=str(a.inputs),
               ONTOGRAPH_FULL_OWL_JAVA=str(a.java), ONTOGRAPH_FULL_OWL_TOOLS=str(a.tools),
               ONTOGRAPH_SHACL_SPARQL_JENA_HOME=str(a.jena_home), ONTOGRAPH_SHACL_SPARQL_JAVA=str(a.jena_java))
    operations = []

    def cli(name, arguments):
        result = subprocess.run([str(a.binary), '--json', *map(str, arguments)], cwd=a.inputs, env=env,
                                capture_output=True, timeout=120,
                                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        # The complete producer record remains local; public evidence is derived separately.
        operations.append(dict(id=name, argv=list(map(str, arguments)), exitCode=result.returncode,
                               stdout=result.stdout.decode('utf-8', 'replace'), stderr=result.stderr.decode('utf-8', 'replace')))
        write(a.output / 'raw-operations.json', operations)
        require(result.returncode == 0, 'Product operation failed: ' + name)
        return json.loads(result.stdout)

    def binding(path, ref):
        return dict(artifactRef=ref, path=path.relative_to(a.inputs).as_posix(), digest='sha256:' + sha(path))

    def jena(name, data, definition, operation, directory):
        request = json.loads((a.inputs / 'fixtures/gufo-interoperability/shacl-sparql/requests/001-endurant-types-shacl.json').read_bytes())
        request.update(requestRef='research:' + name, operation=operation,
                       data=binding(data, 'research:data:' + name), definition=binding(definition, 'research:definition:' + name),
                       storePath=(directory / (name + '-store')).relative_to(a.inputs).as_posix())
        request_path = directory / (name + '-request.json')
        write(request_path, request)
        report = cli(name, ['gufo-shacl-sparql', request_path])
        require(report['receipt']['actualStandardsExecution'] is True, 'Standards execution not actual.')
        require(report['persistence']['reloadVerified'] and report['persistence']['roundTripEqual'], 'Jena reload differs.')
        answer = copy.deepcopy(report['result'])
        # Only request-bound API identities are normalized. RDF rows and typed values stay exact.
        answer.pop('resultRef', None)
        for key in ('dataArtifact', 'definitionArtifact'):
            answer[key].pop('artifactRef', None)
        return answer

    base = 'https://example.org/composition/'
    queries = {
        'organisationAppointments': f'SELECT ?appointment ?person ?organisation WHERE {{ ?appointment <{base}relation/relation%3Amediation> ?person; <{base}relation/relation%3Aorganization-mediation> ?organisation }} ORDER BY ?appointment',
        'qualities': 'SELECT ?quality ?bearer ?value WHERE { ?quality <http://purl.org/nemo/gufo#inheresIn> ?bearer; <http://purl.org/nemo/gufo#hasQualityValue> ?value } ORDER BY ?quality',
        'participations': 'SELECT ?fact ?person ?event WHERE { ?fact a <https://ontograph.dev/vocab/composition#QualifiedParticipation>; <https://ontograph.dev/vocab/composition#participant> ?person; <https://ontograph.dev/vocab/composition#event> ?event } ORDER BY ?fact',
    }
    query_variables = {'organisationAppointments': ['appointment', 'person', 'organisation'],
                       'qualities': ['quality', 'bearer', 'value'], 'participations': ['fact', 'person', 'event']}
    all_runs = []
    for repeat in range(1, a.repeats + 1):
        cases = []
        for oracle in expected['cases']:
            name = oracle['id']
            directory = a.inputs / '.tmp/research-organisation' / a.output.name / f'run-{repeat}' / name
            require(not directory.exists(), 'Use a fresh inputs/output pair; scratch already exists.')
            directory.mkdir(parents=True)
            workspace = directory / 'workspace'
            canonical = workspace / 'data/canonical.json'
            canonical.parent.mkdir(parents=True)
            shutil.copyfile(a.inputs / 'fixtures/canonical/assertion-evidence-thin-slice.json', canonical)
            canonical_before = sha(canonical)
            facts = copy.deepcopy(original_facts)
            if name.startswith('missing-'):
                facts['relators'][0]['mediations'][1]['participantRefs'] = []
            if name == 'empty-role':
                facts['roleMemberships'] = []
            options = dict(profileRef='ontograph.gufo.source-composition.v1', instanceSource=json.dumps(facts),
                           baseIri=base, assumption=oracle['assumption'], at=oracle['at'])
            options_path = directory / 'options.json'
            write(options_path, options)
            arguments = ['ontouml-import', workspace, model, '--serialization-profile', 'ontouml-schema@1.0.2',
                         '--source-artifact', 'artifact:research-organisational-case', '--composition', options_path]
            imported = cli(f'{repeat}-{name}-import', arguments)
            report = imported['sourceComposition']
            require(report['sourceValidationOutcome'] == oracle['sourceOutcome'], 'Source outcome differs: ' + name)
            persisted_path = workspace / imported['importRecordPath']
            persisted_bytes = persisted_path.read_bytes()
            persisted = json.loads(persisted_bytes)
            require(persisted['report'] == imported, 'Persisted report differs.')
            readback = cli(f'{repeat}-{name}-readback', ['model', 'composition', 'readback', '--workspace', workspace,
                                                       '--import-ref', imported['importRef']])
            for key in ('individuals', 'relators', 'roleMemberships'):
                require([{k: v for k, v in row.items() if v is not None} for row in readback[key]] == sorted(facts[key], key=lambda row: row['id']),
                        'Readback differs: ' + key)
            require(cli(f'{repeat}-{name}-reimport', arguments) == imported and persisted_path.read_bytes() == persisted_bytes,
                    'Source-assisted reimport differs.')
            workspace_before_readonly = inventory(workspace)
            graph_path = directory / 'generated.ttl'
            graph_path.write_bytes(report['graph'].encode())
            shapes_path = directory / 'generated-shapes.ttl'
            shapes_path.write_bytes(report['shapes'].encode())
            require(report['graphDigest'] == 'sha256:' + sha(graph_path) and report['shapesDigest'] == 'sha256:' + sha(shapes_path),
                    'Producer graph/shape digest differs from exact written bytes.')
            reload_path = directory / 'reloaded.ttl'
            reload_path.write_bytes(persisted['report']['sourceComposition']['graph'].encode())
            require(isomorphic(Graph().parse(graph_path), Graph().parse(reload_path)), 'Reload graph differs.')
            generated = Graph().parse(graph_path)
            for restriction in expected['expectedGeneratedRestrictions']:
                owner = URIRef(base + 'class/' + quote(restriction['ownerRef'], safe=''))
                prop = URIRef(base + 'relation/' + quote(restriction['propertyRef'], safe=''))
                target = URIRef(base + 'class/' + quote(restriction['targetRef'], safe=''))
                matches = [node for node in generated.objects(owner, RDFS.subClassOf)
                           if (node, OWL.onProperty, prop) in generated and (node, OWL.onClass, target) in generated]
                require(len(matches) == 1, 'Qualified mediation restriction missing or ambiguous.')
                node = matches[0]
                require([int(v) for v in generated.objects(node, OWL.minQualifiedCardinality)] == [restriction['minQualifiedCardinality']],
                        'Source mediation minimum not preserved in generated OWL.')
                require(not list(generated.objects(node, OWL.maxQualifiedCardinality)), 'Invented exact-one/maximum restriction.')
            shacl = jena(f'{repeat}-{name}-shacl', graph_path, shapes_path, 'shacl-validation', directory)
            require(shacl['conforms'] is oracle['shacl'], 'SHACL outcome differs.')
            answers = {}
            for query_name, text in queries.items():
                query_path = directory / (query_name + '.rq')
                query_path.write_text(text + '\n', encoding='utf-8')
                answer = jena(f'{repeat}-{name}-{query_name}', graph_path, query_path, 'sparql-select', directory)
                reloaded = jena(f'{repeat}-{name}-{query_name}-reload', reload_path, query_path, 'sparql-select', directory)
                require(answer == reloaded, 'Typed query answer changed after reload.')
                require(answer['variables'] == query_variables[query_name], 'SELECT variable order differs.')
                rows = [{key: dict(value=value, kind='literal' if key == 'value' else 'uri',
                                   datatype='http://www.w3.org/2001/XMLSchema#decimal' if key == 'value' else None,
                                   language=None) for key, value in row.items()} for row in oracle['queryRows'][query_name]]
                require(answer['rows'] == rows, 'Independent query oracle differs: ' + query_name)
                answers[query_name] = answer
            combined = directory / 'offline-owl.nt'
            graph = Graph().parse(graph_path)
            graph.parse(a.inputs / 'fixtures/gufo-interoperability/full-reasoner/sources/gufo-v1.0.0.ttl', format='turtle')
            graph.serialize(combined, format='nt', encoding='utf-8')
            request_path = directory / 'consistency.json'
            write(request_path, dict(schemaVersion='ontograph.full-owl-request.v1', requestRef='research:' + name,
                                     operation='consistency', premise=binding(combined, 'research:premise'), conclusion=None,
                                     classIri=None, imports=[], limits=dict(timeoutMs=30000, memoryLimitMib=512,
                                     maxStdoutBytes=1048576, maxStderrBytes=262144, networkPolicy='offline-mapped-imports')))
            owl = cli(f'{repeat}-{name}-owl', ['gufo-full-owl-reason', request_path])
            require(owl['executionHealth'] == 'completed' and owl['result']['status'] == 'executed', 'OWL not executed.')
            require(owl['result']['consistent'] is expected.get('owlConsistent', True), 'OWL consistency differs.')
            entailments = {}
            for claim in expected['entailmentClaims']:
                conclusion = directory / (claim['name'] + '.ttl')
                conclusion.write_text(claim['text'] + '\n', encoding='utf-8')
                request = json.loads(request_path.read_bytes())
                request.update(requestRef='research:' + name + ':' + claim['name'], operation='entailment',
                               conclusion=binding(conclusion, 'research:conclusion:' + claim['name']))
                entailment_path = directory / (claim['name'] + '-owl-request.json')
                write(entailment_path, request)
                answer = cli(f'{repeat}-{name}-{claim["name"]}-owl', ['gufo-full-owl-reason', entailment_path])
                require(answer['executionHealth'] == 'completed' and answer['result']['status'] == 'executed', 'Entailment not executed.')
                require(answer['result']['entailed'] is claim['entailed'], 'Independent entailment oracle differs: ' + claim['name'])
                entailments[claim['name']] = answer['result']['entailed']
            active = [row['sourceId'] for row in report['queryRecords'] if row['kind'] == 'roleMembership' and row['evaluation']['membership'] == 'inside']
            require(active == oracle['activeRoleIds'], 'Active explicit membership records differ.')
            require(sha(canonical) == canonical_before and inventory(workspace) == workspace_before_readonly,
                    'Canonical/workspace mutated by read-only operations.')
            public = a.output / f'run-{repeat}' / name
            for filename in ('generated.ttl', 'generated-shapes.ttl'):
                dest = public / filename
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(directory / filename, dest)
            write(public / 'composition.json', report)
            write(public / 'readback.json', readback)
            cases.append(dict(id=name, sourceOutcome=report['sourceValidationOutcome'], shacl=shacl,
                              owlConsistent=owl['result']['consistent'], entailments=entailments, activeRoleIds=active, answers=answers,
                              graphSha256=sha(graph_path), shapesSha256=sha(shapes_path),
                              canonicalSha256=canonical_before, canonicalUnchanged=True,
                              reloadIsomorphic=True, sourceAssistedReimportEqual=True))
            print(f'run-{repeat} {name}: matched independent oracle', flush=True)
        all_runs.append(cases)
    require(all(run == all_runs[0] for run in all_runs), 'Repeated semantic results differ.')
    require(before == {name: inventory(a.inputs / name) for name in before}, 'Protected input changed.')
    write(a.output / 'results.json', dict(schemaVersion='ontograph.research.organisation-results.v1',
          mode='actual', runtimeCommit=a.runtime_commit, binarySha256=sha(a.binary),
          modelSha256=sha(model), instanceSha256=sha(facts_path), oracleSha256=sha(expected_path),
          repeats=a.repeats, cases=all_runs[0], repeatEqual=True, inputNonmutation=True,
          adopted=False, comprehensiveGateCredit=0, operationCount=len(operations),
          limitations=['Selected source constraints only; generic SHACL does not enforce each typed mediation minimum.',
                       'Explicit half-open membership records; no temporal role commitment inferred from labels.',
                       'Persistence is staged candidate readback/regeneration; reimport requires original source.']))
    write(a.output / 'tool-identities.json', dict(runtimeCommit=a.runtime_commit, binarySha256=sha(a.binary),
          packageManifestSha256=sha(package_path), pythonVersion=platform.python_version(), rdflibVersion=rdflib.__version__,
          javaSha256=sha(a.java), jenaJavaSha256=sha(a.jena_java), owlTools=inventory(a.tools),
          jenaClasspath=inventory(a.jena_home / 'lib')))


if __name__ == '__main__':
    main()
