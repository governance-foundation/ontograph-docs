# Semantic viewpoints research demonstration

Status: RD-0 v1 contract for #2775 under epic #2774. This freezes delivery
interfaces and acceptance obligations; it does not establish their implementation.

## Question, audience and canonical authority

How can one source-grounded organisational case retain connected conceptual
identities while serving distinct conceptual, organisational and OWL/gUFO views,
and which commitments survive or are reduced in each view?

The intended reader is an ontology researcher inspecting the conceptual choices,
actual evidence, limitations and reproduction method. Begin with the question
and conceptual case, then inspect identity and mapping, distinguish reasoning
from validation, reproduce selected results, and consider explicit open questions.
Operation counts and engineering logs belong in the evidence appendix.

The canonical model retains OntoUML-grounded identity, dependence, roles,
relators, events, normativity and provenance. OWL and gUFO are purpose-specific
projections; their expressive limits do not redefine canonical meaning. Preserve
source commitments and connected identities without inferring rigidity, identity,
temporal roles or normative authority from labels alone.

Governing anchors: [canonical model](../canonical-model/README.md),
[OntoUML](../ontouml/README.md), [provenance](../provenance/README.md),
[adapter contract](../adapters/backend-adapter-contract.md),
[CLI](../cli/README.md), [query application](../query-application/README.md),
[source composition](../ontouml/giancarlo-demonstration.md) DEMO-001..009,
[nine-source suite](../ontouml/gufo-nine-examples/README.md) NINE-001..015,
[interoperability](../ontouml/gufo-interoperability-foundation.md) GUFO-IF-001..018,
and [documentation publication](../documentation-site/README.md).

## Requirements

| ID | Acceptance obligation | Child |
| --- | --- | --- |
| RDR-001 | Every substantive claim is `demonstrated`, `proposed` or `open`; demonstrated claims bind exact scope, input/output/runtime/tool identities and independent-review state. Missing evidence never upgrades a claim. | RD-0, all |
| RDR-002 | Explain the research question through one neutral organisational case, with an OntoUML diagram, machine-readable source, instances and explicit modelling rationale that agree. Retain legitimate scholarly attribution and actual license status; an undeclared project/data grant remains UNLICENSED, separately from CC-BY upstream sources. | RD-2 |
| RDR-003 | Identity mapping connects source elements, typed candidates, genuine canonical objects where present and display/projection elements. State each identity domain and lifecycle; candidate admission is not canonical acceptance. Equal labels/values establish neither equality nor inequality. | RD-2, RD-4, RD-6 |
| RDR-004 | Mapping records distinguish asserted, derived, accepted enrichment, omitted and unresolved information. Accepted enrichment requires a separate recorded decision and authority; no actual accepted enrichment is claimed without that evidence. Every reduction declares target purpose, retained meaning, losses and open questions. | RD-2, RD-3, RD-4 |
| RDR-005 | A separate non-gUFO OWL exchange shows exact input, actual supported import/staging result, export and independently specified comparison. Report absent conceptual commitments and unsupported constructs; package original source bytes even when API import does not retain them. Current governed runtime output paths take precedence over historical architecture examples. Source staging does not become canonical semantic lift. | RD-3 |
| RDR-006 | The organisational journey traces source model and instances through actual product representation to generated gUFO output. Explain a meaningful typed query and actual diagnostic, with source/mapping pointers and the precise supported operation. Proposed steps remain labelled. | RD-4 |
| RDR-007 | OWL consistency, positive entailment, forbidden entailment/non-entailment, finite-graph validation, SHACL diagnostics, query answers and conceptual correctness remain separately explained. Absence is not negation; consistency is not conceptual endorsement. | RD-1, RD-3, RD-4 |
| RDR-008 | Reuse qualified nine-source evidence with seven positive and two expected-invalid cases, exact source/license pins and successor independent receipt. Original counters and historical failures remain immutable. Nine cases do not establish general OntoUML transformation or full gUFO coverage. | RD-1 |
| RDR-009 | Persistence/reload and comparison name their exact direction and equivalence criterion: typed answer preservation, deterministic bytes where declared, complete RDF isomorphism or source-assisted reimport. No arbitrary target-only inverse or universal losslessness claim. | RD-3, RD-4 |
| RDR-010 | Static pages provide a coherent academic narrative, readable diagrams with legends and text alternatives, visible claim status, mapping/gap tables, evidence navigation and usable downloads. Preserve useful existing URLs/navigation. | RD-5 |
| RDR-011 | A visually checked 4–6 page technical note agrees with the web narrative, includes methods/results/limitations and focused scholarly questions, and uses verified citations. | RD-7 |
| RDR-012 | A versioned reproduction archive includes exact original inputs, mappings, outputs, commands, expected results, runtime/tool requirements, checksums and licenses. A fresh independent reviewer completes the documented journey using only that package and declared prerequisites. | RD-7, RD-8 |
| RDR-013 | Public artifacts use an explicit checksum/byte-count allowlist. Exclude private host paths, credentials, account snapshots and unlicensed distributions; public instructions must not depend on checkout-local `.tmp` links. Preserve authoritative originals separately when neutral presentation aliases are needed. | RD-5, RD-7 |
| RDR-014 | The accepted minimum explorer is an accessible recorded read-only inspection of conceptual, organisational and OWL/gUFO views of this case, using shared identity mappings, source/mapping/status inspection and table/keyboard alternatives. Recorded results and illustrative fixtures are labelled. Unsupported views are explicit gaps. | RD-6 |
| RDR-015 | Live explorer mode is optional and separately capability-gated: use actual supported public operations, coherent real revision identities and real outcomes only. No arbitrary commands or browser raw-storage access. Rendering and selection cannot assert, approve or promote knowledge. | RD-6 |
| RDR-016 | Static research pages/note/package form the first milestone. Explorer delivery runs additively and must satisfy RDR-014 before whole-epic closure; its absence cannot be hidden by a static milestone. | RD-0, RD-8 |
| RDR-017 | Independent semantic review, complete package reproduction and technical/accessibility review are separately recorded and bind reviewed exact bytes. Authors may verify their work but cannot supply its independent acceptance. | RD-1, RD-2, RD-5, RD-7, RD-8 |
| RDR-018 | Record source merged, package verified, publication authorised and site live separately. Follow the actual site repository policy and required final human publication decision after a concrete reviewable build exists. Verify live pages, links and served download hashes after publication. | RD-8 |
| RDR-019 | Shared Console/runtime/pilot owners remain authoritative. No restricted #2691 program executes in this epic. New issue branches start from freshly integrated develop, every commit is promptly pushed, linked cross-repo PRs and closure records identify exact results and retained ownership. | all |
| RDR-020 | Comprehensive C0–C7, second-backend qualification, full Console delivery, storage migration, release, deployment, expert endorsement and held-out assurance remain separate. This demonstration creates no gate credit or publication authority. | all |

The worked mediation source may declare separate person/organisation cardinalities
`1..*`; never silently rewrite these as exact-one. The current generic generated
SHACL `mediates` minimum of two does not enforce each relation's class-specific
minimum. Record that validation gap prominently, with conceptual source and actual
validator outcomes separate.

## Frozen artifact interfaces v1

These are delivery DTOs, not new canonical runtime schemas. Producers serialize
UTF-8 JSON with a `schemaVersion` and stable record IDs. Paths are package-relative
POSIX paths with no absolute location or traversal. SHA-256 values are 64 lowercase
hexadecimal characters; byte lengths are nonnegative integers. Consumers reject
duplicate IDs, unresolved required references, missing artifacts and digest drift.
Version incompatible changes explicitly; the coordinator approves additive
producer/consumer changes through a new freeze checkpoint before integration.
Indexes/manifests may exclude their own digest to avoid recursive hash dependency;
bind those files externally in the archive/site index and state the exclusion.

| Artifact / schemaVersion | Required fields and semantics |
| --- | --- |
| `case-dossier.json` / `ontograph.research.case.v1` | `caseRef`, `title`, `sourceRefs[]`, `modelArtifactRef`, `instanceArtifactRef`, `identityMap[]`, `mappingArtifactRef`, `claimArtifactRef`, `evidenceIndexRef`, `viewpointArtifactRefs[]`. Identity row: `id`, `sourceElementRef`, `candidateRef` nullable, `canonicalRef` nullable, `projectionRefs[]`, `displayRefs[]`, `identityDomain`, `interpretationState`, `evidenceRefs[]`, `gapRefs[]`. Null canonicalRef means no demonstrated canonical object; labels never substitute for IDs. |
| `mappings.json` / `ontograph.research.mappings.v1` | `caseRef`, `mappings[]`. Row: `id`, `sourceRefs[]`, `targetRefs[]`, `purpose`, `status` (`asserted`, `derived`, `accepted-enrichment`, `omitted`, `unresolved`), `rationale`, `retainedMeaning[]`, `reductions[]`, `evidenceRefs[]`, `gapRefs[]`, `decisionRef` nullable. Enrichment needs a nonnull decisionRef; derivation needs an executable evidenceRef or is proposed. |
| `claims.json` / `ontograph.research.claims.v1` | `caseRef`, `claims[]`. Row: `id`, `statement`, `status` (`demonstrated`, `proposed`, `open`), `scope`, `requirementRefs[]`, `evidenceRefs[]`, `reviewState` (`unreviewed`, `independently-reviewed`, `finding-open`), `nonclaims[]`, `gapRefs[]`. Demonstrated requires evidence; independent status requires a distinct reviewer receipt. |
| `evidence-index.json` / `ontograph.research.evidence.v1` | `artifacts[]`, `executions[]`, `reviews[]`. Artifact: `id`, `path`, `mediaType`, `bytes`, `sha256`, `sourceRef`, `licenseRef`. Execution: `id`, `mode` (`actual`, `recorded`, `fixture`), `inputRefs[]`, `outputRefs[]`, `sourceCommit`, `runtimeIdentityRef` nullable, `toolIdentityRefs[]`, `commandRef`, `exitCode` nullable, `outcome`, `limitations[]`. Recorded points to retained actual execution; fixture never proves actual standards execution. Review: `id`, `reviewedArtifactRefs[]`, `reviewerRole`, `independent`, `outcome`, `receiptRef`. |
| `viewpoint.json` / `ontograph.research.viewpoint.v1` | `id`, `caseRef`, `kind` (`conceptual`, `organisational`, `owl-gufo`), `mode` (`recorded`, `fixture`, `live`), `datasetRef` nullable, `revisionRef` nullable, `entities[]`, `relations[]`, `claimRefs[]`, `limitations[]`. Entity/relation rows carry `id`, `identityMapRef`, `sourceRefs[]`, `mappingRefs[]`, `claimRefs[]`, `status`, `label`. Live requires genuine dataset/revision binding; recorded/fixture never invent one. Accessible tables expose all substantive records. |
| `package-manifest.json` / `ontograph.research.package.v1` | `packageRef`, `version`, `sourceCommits[]` (repository, commit), `artifactIndexRef`, `journeyCommandRef`, `expectedOutcomeRefs[]`, `prerequisiteRefs[]`, `licenseRefs[]`, `claimRefs[]`, `limitations[]`. Manifest indexes package contents without requiring its own recursive checksum. Archive checksum is recorded externally in the site evidence index. |

Source, mapping, candidate, generated graph, standards receipt, review, Decision
and Promotion refs remain distinct. A dossier does not manufacture runtime
governance records. Public rendering may use neutral aliases with explicit
identity-map entries, while exact executed source bytes and digests remain intact.

## Evidence baseline and claim boundaries

Inspection baseline: integrated source `c89921db3535449f4cf86be891806eb948547fe6`;
authoring starts from `371c73e7008fe091d66e8ebb77c34fb5e8e8aa2c`. Refresh producer
heads and review receipts before integration or publication.

| Stream | Demonstrated bounded evidence | Explicit residual boundary |
| --- | --- | --- |
| Organisational source composition | `docs/acceptance/giancarlo-demonstration/verification.json` and `independent-review/verification.json`; runtime `66ca35dcc91bec9bbf583844e772e3955fb8c810`, installed binary SHA-256 `44e7ef1cdae1928d10d1d03fa3824c8e3745db29c45e061d82cf03b8752dffe8`; independent installed reproduction retained. | Existing source path is historical; new public titles/copy are neutral. Selected query/persistence/source-assisted checks do not prove normative staffing authority or universal temporal mapping. This runtime differs from the nine-source runtime. |
| Nine direct gUFO sources | `docs/acceptance/gufo-nine-examples/suite-2026-10-09/verification.json` plus `independent-review-2026-10-09/verification.json`; runtime `1c3e2f7d4f1957cf6061b7f03386e3adaf9758e5`, binary SHA-256 `688c5fc66d6b61963877fe5bd29324938f3cb03216eec58e0994137e0ee34a9d`; successor independently reviewed 9/9. | Original author receipt remains historical 0/9 reviewed. This is typed candidate admission/regeneration from pinned Turtle, not general OntoUML transformation, canonical adoption or API parity. Compiler-input coverage remains partial. |
| General OWL bridge | `docs/architecture/owl-import-export-bridge-thin-slice.md`; `rust/ontograph-core/src/owl_bridge.rs`; `fixtures/owl/mini-bridge-source.owl`. Source staging preserves its declared bridge subset and explicit not-promoted interpretation gap. | RD-3 must execute and independently compare its new non-gUFO example. General restriction/individual/datatype-property coverage and canonical semantic lift cannot be assumed from bridge import/export. Unsupported-source retention is tracked separately in #2791; reproduction must retain original bytes without claiming the API did so. |
| Canonical architecture and future views | Existing canonical/provenance/adapter contracts establish the intended semantic authority. | Connected rich views beyond actually observed operations are proposed architecture until producer evidence exists. OWL/gUFO expressivity is not the canonical ceiling. |

The current C0–C7 ledger is
`docs/acceptance/comprehensive-conformance/gate-ledger.v1.json`: 0/8 passed.
Do not execute or consume restricted #2691 pilot programs as reproduction steps.
Its failed observations and pending human exceptions remain with that owner.

## Verification and freeze acceptance

Before RD-0 integration, independently review requirements, DTO references,
ownership, baseline claim boundaries and the separate static/explorer milestones.
Resolve owned Markdown links and run `git diff --check`. No runtime evidence is
created by this documentation check. RD-0 completion requires the pushed PR,
coordinator review and governed integration; a freeze checkpoint may unblock
independent preparation without asserting merged producer implementation.

Each child reports requirement IDs, exact pushed SHA/PR, artifact paths and
acceptance-specific checks. Package reproduction and independent reviews are
required for RD-8; a green build alone does not discharge them. Site source
location is pending the coordinator's explicit arrangement decision: current
documentation policy describes product `website/` as source and ontograph-docs
as distribution mirror, while the epic requests site work in ontograph-docs.
This contract authorizes neither an unreviewed source migration nor deployment.
The coordinator records the resolved arrangement before affected source edits.

See the [delivery and ownership plan](../../docs/plans/semantic-viewpoints-research-demonstration.md).
