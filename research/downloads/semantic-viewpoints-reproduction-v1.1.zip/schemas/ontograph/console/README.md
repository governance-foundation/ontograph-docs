# Console v2 public wire boundary

Issue #2751 binds CONSOLE-003 through CONSOLE-010 and CONSOLE-013. The frozen
producer/consumer interface is UI-0 v2 in PR #2771, exact input
`aa05a3fcbb4087b567cb8d84371beb06163c7321`. Runtime controls are RT-0 in PR #2772,
exact input `197d90e966c4e53703c52950d947962ef9c7618a`.

`console.v2.schema.json` supplies closed JSON Schema 2020-12 `$defs`. Register
that document locally when compiling a wrapper; resolve no untrusted URL. Wire
decoders must validate the requested definition before producing branded types.
Digests accept 64 lower-case hex characters with an optional `sha256:` prefix. Revision/dataset keys
are opaque equality tokens, never ordered timestamps or semantic versions.

| Public route | Current implemented result |
| --- | --- |
| GET /console/capabilities | Honest capability/guard gaps, schema references and bounds |
| POST /console/snapshot?workspace=selector | Strict v2 request, explicit unsupported identity/capture gap; invalid wire scope is rejected |
| POST /console/inspect?workspace=selector | Strict pinned request; HTTP 409 identity prerequisite, never an implicit base fallback |
| POST /console/operations?workspace=selector | Allowlisted typed payload; unsupported receipt until native identity and guards are connected |

The selector reuses the existing server containment policy. It is an operational
locator, never a canonical workspace identity. No route accepts commands,
filesystem payload paths, arbitrary URLs or browser access to private state.
Malformed/duplicate/unknown fields return HTTP 400; transport requests over
4 MiB return 413. Request validation compiles the local closed schema definitions
once, after duplicate/depth checks and before typed deserialization. Existing Host/Origin/JSON/loopback controls remain authoritative.
Cancellation before sending belongs to the client. Losing a response after
sending cannot prove rejection/nonmutation; reconciliation belongs to native
operation ownership.

The current workspace manifest/metadata has no verified canonical workspace ID
or non-reused incarnation. History lock/read_graph can provide coherent canonical
state, but that alone cannot satisfy the frozen v2 revision domain. The runtime
prerequisite is tracked in #2758/#2765. Public capabilities therefore disable
live snapshots and operations. This is a reproduced current-runtime gap, not a
requirement to complete storage migration.

`ontograph_engine::console::CapturedScene` is an immutable projection adapter
for a future native one-owner capture. Its tests use explicitly constructed
captures and prove projection/inspection behavior only. It rejects missing
selected proposals, stale revisions, mismatched dataset/bytes, incomplete
inspection and oversized whole scopes. It retains all same-ID base/proposal
variants with collision-resistant display IDs. Depth-zero through depth-two exploration reuses native typed adjacency. Explicit
Assertion and DomainMediation records project their canonical ID and endpoint
roles; other property incidence remains inspectable rather than invented as a
canonical relationship. Pagination remains an explicit gap. It does not infer
canonical relations from generic property references or
semantic acceptance from operation success. Package version remains null without
a single verified package scope.

`validate_native_candidate` calls the existing public read-only pinned candidate
validator with actor/base consistency checks. Native findings and output hash are
retained. This adapter is not exposed as a successful v2 operation until the
native capture owner supplies its identity/revision binding. Other lifecycle
writes and generic governed-write are excluded until native atomic base/subject
guards and authoritative receipts are connected.

Focused verification: `cargo check -p ontograph-server --locked` and
`cargo test -p ontograph-server --test console_boundary --locked`. These are
source verification, not installed live console acceptance or C0-C7 evidence.

The additive trusted bootstrap is governed by #2796. POST
`/console/context?workspace=selector` accepts separately versioned
`ontograph.console-context.v1`, requestId, generation and scope. It accepts no
claimed workspaceId or datasetKey. Its correlated unsupported/failed response
contains no fabricated ReadContext. A future resolved descriptor must be produced
from native verified identity/incarnation and the requested scope. This addition
does not change v2 scene or operation shapes and does not initialize a workspace.
