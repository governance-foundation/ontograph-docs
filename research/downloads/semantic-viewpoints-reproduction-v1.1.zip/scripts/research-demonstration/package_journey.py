"""Execute OWL, organisational and all nine corpus cases from a verified archive."""
import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
sys.dont_write_bytecode = True
from package_verify import require, safe, sha, verify_root

RUNTIME = '1c3e2f7d4f1957cf6061b7f03386e3adaf9758e5'
BINARY = '688c5fc66d6b61963877fe5bd29324938f3cb03216eec58e0994137e0ee34a9d'


def verify_prerequisites(a):
    require(os.name == 'nt', 'Recorded acceptance lane requires Windows')
    require(platform.python_version() == '3.14.6', 'Pinned Python version is 3.14.6')
    import rdflib
    require(rdflib.__version__ == '7.6.0', 'Pinned RDFLib version is 7.6.0')
    require(not sys.flags.optimize, 'Python assertions must be enabled')
    require(sha(a.binary.read_bytes()) == BINARY, 'Pinned product binary digest mismatch')
    installed_manifest = (a.binary.parent / 'release-manifest.json').read_bytes()
    require(installed_manifest == (a.root / 'prerequisites/runtime-release-manifest.json').read_bytes(), 'Complete pinned installed release manifest differs')
    package = json.loads(installed_manifest)
    require(len(package['files']) == 79, 'Pinned installed package population differs')
    require(package['gitCommit'] == RUNTIME, 'Installed runtime source identity mismatch')
    names = [x['path'] for x in package['files']]
    require(len({x.casefold() for x in names}) == len(names) and a.binary.name in names, 'Duplicate/missing installed binary entry')
    for row in package['files']:
        path = a.binary.parent.joinpath(*safe(row['path']).parts)
        require(path.resolve().is_relative_to(a.binary.parent.resolve()), 'Installed manifest alias escape')
        require(path.stat().st_size == row['bytes'] and sha(path.read_bytes()) == row['sha256'].removeprefix('sha256:'), 'Installed package file drift: ' + row['path'])
    pins = json.loads((a.root / 'prerequisites/tool-identities.json').read_bytes())
    require(sha(a.java.read_bytes()) == pins['javaSha256'], 'Java 17 executable digest mismatch')
    require(sha(a.jena_java.read_bytes()) == pins['jenaJavaSha256'], 'Java 21 executable digest mismatch')
    actual_owl = {p.relative_to(a.tools).as_posix(): sha(p.read_bytes()) for p in a.tools.rglob('*') if p.is_file()}
    actual_jena = {p.name: sha(p.read_bytes()) for p in (a.jena_home / 'lib').glob('*') if p.is_file()}
    require(actual_owl == pins['owlFiles'], 'OWL provider complete-file identity mismatch')
    require(actual_jena == pins['jenaFiles'], 'Jena complete classpath identity mismatch')
    require(not any((p / '.git').exists() for p in [a.binary.parent, *a.binary.parent.parents]), 'Install runtime outside Git')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'binary', 'java', 'tools', 'jena-home', 'jena-java', 'work-dir'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    for name in ('root', 'binary', 'java', 'tools', 'jena_home', 'jena_java', 'work_dir'):
        setattr(a, name, getattr(a, name).resolve())
    verify_root(a.root)
    verify_prerequisites(a)
    require(not a.work_dir.exists(), 'Use an absent fresh work directory')
    require(not a.work_dir.is_relative_to(a.root), 'Evidence work directory must be outside package')
    require(not any((x / '.git').exists() for x in [a.work_dir.parent, *a.work_dir.parents]), 'Fresh reproduction must be outside Git')
    a.work_dir.mkdir(parents=True)
    tools = ['--binary', str(a.binary), '--java', str(a.java), '--tools', str(a.tools),
             '--jena-home', str(a.jena_home), '--jena-java', str(a.jena_java)]
    lanes = [('owl', 'scripts/research-demonstration/owl_reproduce.py'),
             ('organisation', 'scripts/research-demonstration/organisation_reproduce.py'),
             ('nine', 'scripts/run_gufo_nine_examples.py')]
    results = []
    for lane, script in lanes:
        copied = a.work_dir / (lane + '-inputs')
        shutil.copytree(a.root, copied)
        out = a.work_dir / (lane + '-evidence')
        if lane == 'owl':
            argv = [sys.executable, str(copied / script), '--binary', str(a.binary), '--runtime-commit', RUNTIME,
                    '--inputs', str(copied / 'fixtures/research-demonstration/owl'), '--output', str(out)]
        else:
            argv = [sys.executable, str(copied / script), *tools, '--inputs', str(copied), '--output', str(out)]
            argv += ['--source-commit', RUNTIME] if lane == 'nine' else ['--runtime-commit', RUNTIME, '--repeats', '1']
        print('Executing complete ' + lane + ' lane', flush=True)
        result = subprocess.run(argv, cwd=copied, capture_output=True)
        # Raw subprocess reports can contain host paths and remain private local evidence.
        (a.work_dir / (lane + '.stdout.txt')).write_bytes(result.stdout)
        (a.work_dir / (lane + '.stderr.txt')).write_bytes(result.stderr)
        require(result.returncode == 0, lane + ' execution failed; inspect local evidence')
        receipt_name = 'comparison.json' if lane == 'owl' else 'results.json' if lane == 'organisation' else 'verification.json'
        data = (out / receipt_name).read_bytes()
        receipt = json.loads(data)
        if lane == 'nine':
            require(receipt['passedCases'] == receipt['selectedCases'] == 9, 'Nine-case journey incomplete')
            require(receipt['status'] == 'passed', 'Nine-case suite failed')
        elif lane == 'organisation':
            require([row['id'] for row in receipt['cases']] ==
                    ['valid', 'missing-cwa', 'missing-owa', 'end-boundary', 'empty-role'],
                    'Five-case organisational journey incomplete')
            require(receipt['repeats'] == 1 and receipt['inputNonmutation'], 'Fresh organisational scope differs')
            require(all(row['canonicalUnchanged'] and row['reloadIsomorphic'] and
                        row['sourceAssistedReimportEqual'] for row in receipt['cases']),
                    'Organisational persistence/nonmutation outcome differs')
        else:
            require(receipt['outcome'] == 'passed' and receipt['supportedTriples'] == 18 and
                    receipt['omittedTriples'] == 4 and not receipt['fullSourceExportIsomorphic'],
                    'Declared OWL reduction outcome differs')
        results.append(dict(id=lane, exitCode=result.returncode, receipt=lane+'-evidence/'+receipt_name,
                            receiptSha256=sha(data), result=receipt))
    verify_root(a.root)
    (a.work_dir / 'journey-results.json').write_text(json.dumps(dict(schemaVersion='ontograph.research.package-journey.v1',
        outcome='passed',runtimeCommit=RUNTIME,binarySha256=BINARY,lanes=results,
        limits=['Author/reviewer role is recorded separately; running this command does not grant independent acceptance.',
                'No C0-C7 credit, canonical adoption, universal inverse, release or publication authority.']),indent=2)+'\n',encoding='utf-8')
    print('Complete three-lane journey passed; all nine corpus and five organisational cases executed.', flush=True)


if __name__ == '__main__':
    main()
