"""Assemble a deterministic, explicit allowlisted research reproduction ZIP."""
import argparse
import json
import mimetypes
import re
import subprocess
import sys
from pathlib import Path
import zipfile
sys.dont_write_bytecode = True
from package_verify import require, safe, sha, check_members

BASE = 'docs/acceptance/research-demonstration/package'


def jbytes(value):
    return (json.dumps(value, indent=2, sort_keys=True)+'\n').encode('utf-8')


def assemble(source, version, note=None):
    members = {}
    def add(path, destination=None):
        name = destination or path
        safe(name)
        require(name not in members, 'Duplicate builder destination: ' + name)
        p = source / path
        require(p.is_file() and not p.is_symlink(), 'Missing/aliased selected source: '+path)
        members[name] = p.read_bytes()
    def tree(folder, destination=None, filter_file=lambda p: True):
        root = source / folder
        require(root.is_dir(), 'Missing selected source folder: '+folder)
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.name != '.gitattributes' and filter_file(p):
                name = p.relative_to(root).as_posix()
                add(p.relative_to(source).as_posix(), (destination+'/'+name) if destination else folder+'/'+name)
    for folder in ['fixtures/research-demonstration/owl', 'fixtures/research-demonstration/organisation',
                   'schemas', 'docs/research-demonstration/case',
                   'docs/acceptance/research-demonstration/owl']:
        tree(folder)
    for path in ['scripts/research-demonstration/owl_reproduce.py',
                 'scripts/research-demonstration/organisation_reproduce.py',
                 'scripts/run_gufo_nine_examples.py',
                 'scripts/research-demonstration/package_verify.py',
                 'scripts/research-demonstration/package_journey.py',
                 'scripts/research-demonstration/package_build.py',
                 'fixtures/canonical/assertion-evidence-thin-slice.json',
                 'fixtures/gufo-interoperability/full-reasoner/sources/gufo-v1.0.0.ttl',
                 'fixtures/gufo-interoperability/full-reasoner/tool-pin.v1.json',
                 'fixtures/gufo-interoperability/owl-reasoner/external-corpus/sources/gufo-f412254.ttl',
                 'fixtures/gufo-interoperability/shacl-sparql/requests/001-endurant-types-shacl.json',
                 'fixtures/gufo-interoperability/shacl-sparql/sources/gufoshapes.ttl',
                 'fixtures/gufo-interoperability/shacl-sparql/apache-jena-6.2.0.tool-pin.json',
                 'fixtures/gufo-interoperability/shacl-sparql/manifest.v1.json',
                 'specs/ontouml/gufo-nine-examples/frozen-oracles.json',
                 'specs/research-demonstration/README.md']:
        add(path)
    tree('fixtures/gufo-interoperability/shacl-sparql/examples')
    tree('fixtures/gufo-interoperability/shacl-sparql/queries')
    pin=json.loads(members['fixtures/gufo-interoperability/shacl-sparql/apache-jena-6.2.0.tool-pin.json'])
    normalizer=pin['normalizationQuery']
    require(normalizer['path'] in members, 'Pinned adapter normalization query absent')
    require(len(members[normalizer['path']]) == normalizer['bytes'] and
            sha(members[normalizer['path']]) == normalizer['sha256'], 'Pinned normalization query drift')
    # Only the preexisting public allowlist: private installed-run ZIPs/logs are excluded.
    tree('website/static/evidence/gufo-nine-examples-2026-10-09', 'evidence/nine',
         lambda p: p.suffix in ('.json', '.ttl'))
    for name in ['audit-result.json']:
        add('docs/acceptance/research-demonstration/nine/'+name, 'evidence/nine/custody-'+name)
    org = 'docs/acceptance/research-demonstration/organisation'
    require((source / org / 'results.json').is_file(), 'Organisation actual results not yet integrated')
    # Explicit public organisation evidence, never raw operations/startup logs.
    for name in ['README.md', 'claims.json', 'commands.json', 'evidence-index.json',
                 'executed-runner.py', 'results.json', 'source-identities.json',
                 'tool-identities.json', 'verification.json']:
        add(org+'/'+name)
    for repeat in [1, 2]:
        for case in ['valid', 'missing-cwa', 'missing-owa', 'end-boundary', 'empty-role']:
            for name in ['composition.json', 'readback.json', 'generated.ttl', 'generated-shapes.ttl']:
                add(f'{org}/run-{repeat}/{case}/{name}')
    for name, dest in [('PACKAGE-README.md','README.md'), ('LICENSE-NOTICES.md','LICENSE-NOTICES.md')]:
        add(BASE+'/'+name,dest)
    tree(BASE+'/notices','notices')
    tree(BASE+'/producer-reviews','evidence/producer-reviews')
    tree(BASE+'/history','evidence/package-history')
    review_source = json.loads(members['evidence/producer-reviews/source.json'])
    add(BASE+'/prerequisites/runtime-release-manifest.json','prerequisites/runtime-release-manifest.json')
    add('website/static/evidence/gufo-nine-examples-2026-10-09/tool-identities.json', 'prerequisites/tool-identities.json')
    if note:
        for name in ['README.md', 'build_note.py', 'technical-note.metadata.json',
                     'visual-review.json', 'technical-note.pdf']:
            add(note.rstrip('/')+'/'+name, 'note/'+name)
    baseline = subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    members['prerequisites/source-identities.json'] = jbytes(dict(schemaVersion='ontograph.research.package-sources.v1',sources=[
        dict(id='source:ontograph-delivery',repository='https://github.com/governance-foundation/ontograph',commit=baseline,
             boundary='Baseline source revision; per-artifact hashes bind assembled bytes, final producer PR binds delivery.'),
        dict(id='source:producer-reviews',repository=review_source['repository'],commit=review_source['sourceCommit'],
             boundary='Two exact independent producer receipts; publication-boundary source excluded.'),
        dict(id='source:gufo-nine',repository='https://github.com/nemo-ufes/gufo',commit='f4122544133544eb4c6c467ba316302ab20b754a'),
        dict(id='source:gufo-projection',repository='https://github.com/nemo-ufes/gufo',commit='12b098158a9244179c5e0e2534cd85254a2d3b7e'),
        dict(id='source:gufoshapes',repository='https://github.com/nemo-ufes/gufoshapes',commit='b95e14b034c93c42323e8beb8c08f697b026e553'),
        dict(id='source:ontouml-schema',repository='https://github.com/OntoUML/ontouml-schema',commit='7a0fe7ef7d4caea8d62f2782fb3681261a75f452')]))
    members['prerequisites/licenses.json'] = jbytes(dict(schemaVersion='ontograph.research.package-licenses.v1',licenses=[
        dict(id='license:project-unlicensed',expression='UNLICENSED',grant=None,noticeRef='LICENSE-NOTICES.md'),
        dict(id='license:gufo-cc-by',expression='CC-BY-4.0',noticeRef='notices/gufo-CC-BY-4.0.txt'),
        dict(id='license:gufoshapes-cc-by',expression='CC-BY-4.0',noticeRef='notices/gufoshapes-CC-BY-4.0.txt'),
        dict(id='license:ontouml-apache',expression='Apache-2.0',noticeRef='notices/ontouml-schema-APACHE-2.0.txt')]))
    members['prerequisites/runtime.json'] = jbytes(dict(schemaVersion='ontograph.research.package-prerequisites.v1',
        platform='Windows',python='3.14.6',rdflib='7.6.0',runtimeCommit='1c3e2f7d4f1957cf6061b7f03386e3adaf9758e5',
        binarySha256='688c5fc66d6b61963877fe5bd29324938f3cb03216eec58e0994137e0ee34a9d',
        completeReleaseManifestRequired=True,releaseManifestRef='prerequisites/runtime-release-manifest.json',
        releaseManifestSha256='b7ce55a1e2553168ba00b5ac6a7b41e55e46a29c50285cbd81632204f9444168',distributionsIncluded=False,
        java='17.0.6 OWL / 21.0.7 Jena',jena='6.2.0',toolIdentityRef='prerequisites/tool-identities.json',
        optionalTechnicalNoteRebuild=dict(reportlab='4.4.9',pypdf='6.10.0',
            visualAcceptance='Separate visual-review receipt; rebuilding resets pending status.'),
        acquisition='Separately installed lawful complete product/provider packages; exact hashes mandatory, no automatic download.',
        licenseRef='LICENSE-NOTICES.md',compilerInputCoverage='partial'))
    artifacts=[]
    for name,data in sorted(members.items()):
        source_ref, license_ref='source:ontograph-delivery','license:project-unlicensed'
        if name.startswith('evidence/producer-reviews/'):
            source_ref='source:producer-reviews'
        elif name == 'notices/gufo-CC-BY-4.0.txt' or (name.startswith('evidence/nine/c') and name.endswith('/executed-source.ttl')):
            source_ref,license_ref='source:gufo-nine','license:gufo-cc-by'
        elif name == 'notices/gufoshapes-CC-BY-4.0.txt':
            source_ref,license_ref='source:gufoshapes','license:gufoshapes-cc-by'
        elif name == 'notices/ontouml-schema-APACHE-2.0.txt':
            source_ref,license_ref='source:ontouml-schema','license:ontouml-apache'
        if name.startswith('schemas/external/ontouml/'):
            source_ref,license_ref='source:ontouml-schema','license:ontouml-apache'
        elif name.endswith('/gufoshapes.ttl'):
            source_ref,license_ref='source:gufoshapes','license:gufoshapes-cc-by'
        elif '/shacl-sparql/examples/' in name or name.endswith('/gufo-f412254.ttl'):
            source_ref,license_ref='source:gufo-nine','license:gufo-cc-by'
        elif name.endswith('/gufo-v1.0.0.ttl'):
            source_ref,license_ref='source:gufo-projection','license:gufo-cc-by'
        artifacts.append(dict(id='artifact:'+name,path=name,bytes=len(data),sha256=sha(data),
            mediaType=mimetypes.guess_type(name)[0] or 'application/octet-stream',sourceRef=source_ref,licenseRef=license_ref))
    members['artifact-index.json']=jbytes(dict(schemaVersion='ontograph.research.evidence.v1',artifacts=artifacts,
        executions=[],reviews=[],sourceIdentitiesRef='prerequisites/source-identities.json',licenseIdentitiesRef='prerequisites/licenses.json',
        checksumExclusion='artifact-index.json and package-manifest.json exclude recursive hashes; external archive checksum binds both.'))
    members['package-manifest.json']=jbytes(dict(schemaVersion='ontograph.research.package.v1',packageRef='package:semantic-viewpoints-'+version,version=version,
        sourceCommits=[dict(repository='https://github.com/governance-foundation/ontograph',commit=baseline),
                       dict(repository=review_source['repository'],commit=review_source['sourceCommit']),
                       dict(repository='https://github.com/governance-foundation/ontograph',commit='1c3e2f7d4f1957cf6061b7f03386e3adaf9758e5')],
        artifactIndexRef='artifact-index.json',journeyCommandRef='scripts/research-demonstration/package_journey.py',
        expectedOutcomeRefs=['README.md','docs/acceptance/research-demonstration/owl/execution/comparison.json',org+'/results.json',
                             'specs/ontouml/gufo-nine-examples/frozen-oracles.json','evidence/nine/independent-review.json'],
        prerequisiteRefs=['prerequisites/runtime.json','prerequisites/tool-identities.json'],licenseRefs=['LICENSE-NOTICES.md','prerequisites/licenses.json'],
        claimRefs=['docs/research-demonstration/case/claims.json','docs/acceptance/research-demonstration/owl/claims.json',
                   org+'/claims.json'],
        limitations=['Private review/distribution preparation; project material UNLICENSED/no general reuse grant.',
                     'Actual complete independent package reproduction pending distinct reviewer receipt.',
                     'No C0-C7, canonical adoption, release/deployment or publication authority.',
                     'Runtime source and delivery source distinct; compiler-input coverage partial.']))
    # Reject host paths in UTF-8 public material, and exclude raw logs/distributions by construction.
    for name,data in members.items():
        if name.endswith(('.json','.md','.py','.txt')):
            text=data.decode('utf-8-sig')
            require(not re.search(r'(?<![A-Za-z])[A-Za-z]:[\\/](?:Users|projects)[\\/]', text), 'Private host path in '+name)
    check_members(members)
    return members


def build(source,output,version,note=None):
    require(not output.exists(), 'Archive destination exists; preserve prior candidates')
    members=assemble(source,version,note)
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_STORED) as z:
        for name,data in sorted(members.items()):
            entry=zipfile.ZipInfo(name,(2026,10,9,0,0,0));entry.create_system=3;entry.external_attr=0o100644 << 16
            z.writestr(entry,data)
    return dict(path=output.name,bytes=output.stat().st_size,sha256=sha(output.read_bytes()),
                members=len(members),schemaVersion='ontograph.research.archive-checksum.v1')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,default=Path('.'));p.add_argument('--output',required=True,type=Path)
    p.add_argument('--version',default='v1');p.add_argument('--technical-note')
    a=p.parse_args();result=build(a.source.resolve(),a.output.resolve(),a.version,a.technical_note)
    verifier = (a.source.resolve() / 'scripts/research-demonstration/package_verify.py').read_bytes()
    (a.output.parent / 'package_verify.py').write_bytes(verifier)
    result['standaloneVerifier'] = dict(path='package_verify.py', bytes=len(verifier), sha256=sha(verifier))
    a.output.with_suffix('.checksum.json').write_bytes(jbytes(result));print(json.dumps(result,sort_keys=True))


if __name__=='__main__':main()
