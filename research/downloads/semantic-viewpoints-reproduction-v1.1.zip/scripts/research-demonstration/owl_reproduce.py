"""Reproduce RD-3 selected RDF preservation; no OWL reasoning or canonical lift."""
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path
import rdflib
from rdflib import Graph
from rdflib.compare import isomorphic


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', required=True, type=Path)
    parser.add_argument('--runtime-commit', required=True)
    parser.add_argument('--inputs', type=Path, default=Path('fixtures/research-demonstration/owl'))
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    binary = args.binary.resolve(strict=True)
    inputs = args.inputs.resolve(strict=True)
    output = args.output.resolve()
    require(not output.exists() or not any(output.iterdir()), 'Use a new/empty output directory; preserve prior evidence.')
    output.mkdir(parents=True, exist_ok=True)
    scratch_root = Path('.tmp').resolve()
    scratch_root.mkdir(exist_ok=True)
    scratch = Path(tempfile.mkdtemp(prefix='rd3-owl-', dir=scratch_root))
    (scratch / '.tmp').mkdir()
    for name in ('source.owl', 'expected-supported.ttl', 'expected-omitted.ttl'):
        shutil.copyfile(inputs / name, scratch / name)
    environment = {k: v for k, v in os.environ.items() if not k.startswith('ONTOGRAPH_')}
    environment['ONTOGRAPH_PROJECT_ROOT'] = str(scratch)
    commands = []
    def run(argv):
        result = subprocess.run([str(binary), *argv], cwd=scratch, env=environment, capture_output=True)
        commands.append(dict(id=f'command:{len(commands)+1}', runtimeIdentityRef='runtime:owl-cli',
                             argv=argv, environment={'ONTOGRAPH_PROJECT_ROOT': '<isolated scratch root>'}, exitCode=result.returncode,
                             stdout=result.stdout.decode('utf-8', 'replace'),
                             stderr=result.stderr.decode('utf-8', 'replace')))
        write(output / 'commands.json', commands)
        require(result.returncode == 0, f'Command failed: {argv}: {commands[-1]}')
    run(['owl-import', 'source.owl', '.tmp/bridge.json'])
    run(['owl-export', '.tmp/bridge.json', '.tmp/export.owl'])
    run(['owl-import', '.tmp/export.owl', '.tmp/reimport.json'])
    run(['owl-export', '.tmp/reimport.json', '.tmp/reexport.owl'])
    for name in ('bridge.json', 'export.owl', 'reimport.json', 'reexport.owl'):
        shutil.copyfile(scratch / '.tmp' / name, output / name)
    source = Graph().parse(inputs / 'source.owl', format='xml')
    expected = Graph().parse(inputs / 'expected-supported.ttl', format='turtle')
    omitted = Graph().parse(inputs / 'expected-omitted.ttl', format='turtle')
    exported = Graph().parse(output / 'export.owl', format='xml')
    reexported = Graph().parse(output / 'reexport.owl', format='xml')
    # Expectations are authored independently, before executing the importer.
    require(isomorphic(source, expected + omitted), 'Original differs from declared supported + omitted graphs.')
    require(isomorphic(exported, expected), 'Export differs from independently specified supported graph.')
    require(not isomorphic(source, exported), 'Full-graph equality unexpectedly true; reassess restriction gap.')
    require(isomorphic(exported, reexported), 'Export -> bridge -> export graph differs.')
    require((output / 'export.owl').read_bytes() == (output / 'reexport.owl').read_bytes(), 'Deterministic export bytes differ.')
    bridge = json.loads((output / 'bridge.json').read_text(encoding='utf-8'))
    require(bridge['governance']['canonicalPromotion'] == 'not-promoted', 'Promotion boundary weakened.')
    require(bridge['governance']['stage'] == 'raw-imported-artifact', 'Staging boundary weakened.')
    require(all(x['interpretationState'] == 'foreign-source-only' for x in bridge['nodes'] + bridge['edges']), 'Foreign-source boundary weakened.')
    require(any(g['blocksPromotion'] for g in bridge['semanticGaps']), 'Blocking interpretation gap absent.')
    require(not (scratch / 'data/canonical.json').exists(), 'Unexpected canonical graph file.')
    write(output / 'comparison.json', dict(schemaVersion='ontograph.research.owl-comparison.v1',
          outcome='passed', inputTriples=len(source), supportedTriples=len(expected), omittedTriples=len(omitted),
          exportTriples=len(exported), fullSourceExportIsomorphic=False, declaredSupportedExportIsomorphic=True,
          sourceEqualsDeclaredSupportedPlusOmitted=True, exportReexportIsomorphic=True,
          exportReexportByteIdentical=True, comparisonDirection='source -> bridge -> export; export -> bridge -> reexport',
          canonicalResult=dict(createdCanonicalObjects=[], promotion='not-promoted',
                               observedCanonicalGraphFile=False, interpretation='foreign-source-only'),
          reasoningExecuted=False, shaclExecuted=False, independentReview='unreviewed',
          limitations=['RDF graph isomorphism proves only the selected structural preservation criterion.',
                       'No OWL consistency, entailment, non-entailment, SHACL or conceptual correctness verdict.',
                       'The existential restriction is absent from bridge/export, retained only in packaged source.',
                       'No OntoUML identity, rigidity, role, dependence or normative commitment inferred from names.',
                       'No canonical lift, universal inverse, arbitrary OWL support or C0-C7 credit.']))
    write(output / 'identities.json', dict(schemaVersion='ontograph.research.owl-identities.v1',
          runtime=dict(id='runtime:owl-cli', binary='ontograph.exe', sha256=digest(binary),
                       sourceCommit=args.runtime_commit, provenance='Retained product CLI; runtime source revision is caller-declared and checked against the retained package by the reviewer.'),
          tools=[dict(id='tool:python', version=platform.python_version()), dict(id='tool:rdflib', version=rdflib.__version__),
                 dict(id='tool:runner', sha256=digest(Path(__file__)))],
          inputs=[dict(path=name, sha256=digest(inputs/name), bytes=(inputs/name).stat().st_size)
                  for name in ('source.owl', 'expected-supported.ttl', 'expected-omitted.ttl')]))
    print('RD-3 passed: selected RDF graph preserved, declared restriction omitted, no canonical promotion.')
    print('Scratch retained under .tmp for inspection; output contains portable commands and identities.')


if __name__ == '__main__':
    main()



