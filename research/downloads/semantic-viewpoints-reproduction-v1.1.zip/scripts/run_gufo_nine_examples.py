"""Installed source admission evidence; preserve each invocation in a fresh directory."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import rdflib
from rdflib import Graph, RDF, OWL, URIRef
rdflib.NORMALIZE_LITERALS = False
from rdflib.compare import isomorphic

BASE = 'https://purl.org/nemo/gufo-examples/endurant-types#'
GUFO = 'http://purl.org/nemo/gufo#'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')

def main():
    if os.sys.flags.optimize:
        raise RuntimeError('assertions must be enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('binary', 'inputs', 'output', 'java', 'tools', 'jena-home', 'jena-java'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--case', type=int, choices=range(1, 10))
    args = parser.parse_args()
    for key in ('binary', 'inputs', 'output', 'java', 'tools', 'jena_home', 'jena_java'):
        setattr(args, key, getattr(args, key).resolve())
    for root in (args.inputs, args.binary.parent):
        assert not any((p / '.git').exists() for p in (root, *root.parents)), root
    assert not args.output.exists(), 'retain old observations; use a fresh output directory'
    temp = args.inputs / '.tmp/nine-example-run'
    assert not temp.exists(), 'use a fresh input directory per complete run'
    temp.mkdir(parents=True)
    args.output.mkdir(parents=True)
    (args.output / 'executed-runner.py').write_bytes(Path(__file__).read_bytes())
    package = json.loads((args.binary.parent / 'release-manifest.json').read_bytes())
    assert package['gitCommit'] == args.source_commit
    for entry in package['files']:
        path = (args.binary.parent / entry['path']).resolve()
        assert path.is_relative_to(args.binary.parent)
        assert path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256'].removeprefix('sha256:')
    expectations_path = args.inputs / 'specs/ontouml/gufo-nine-examples/frozen-oracles.json'
    expected = json.loads(expectations_path.read_bytes())
    (args.output / 'executed-expectations.json').write_bytes(expectations_path.read_bytes())
    protected = {p.relative_to(args.inputs).as_posix(): sha(p)
                 for folder in ('fixtures', 'schemas', 'specs') for p in (args.inputs / folder).rglob('*') if p.is_file()}
    env = {k: v for k, v in os.environ.items() if k.upper() in ('SYSTEMROOT', 'WINDIR', 'USERPROFILE')}
    env.update(PATH=str(Path(os.environ['SystemRoot']) / 'System32'), TEMP=str(temp), TMP=str(temp),
        ONTOGRAPH_PROJECT_ROOT=str(args.inputs), ONTOGRAPH_INPUT_BASE=str(args.inputs),
        ONTOGRAPH_FULL_OWL_JAVA=str(args.java), ONTOGRAPH_FULL_OWL_TOOLS=str(args.tools),
        ONTOGRAPH_SHACL_SPARQL_JENA_HOME=str(args.jena_home), ONTOGRAPH_SHACL_SPARQL_JAVA=str(args.jena_java))
    operations = []

    def cli(name, command, ok=True):
        result = subprocess.run([str(args.binary), '--json', *map(str, command)], cwd=args.inputs,
            env=env, stdin=subprocess.DEVNULL, capture_output=True, timeout=120,
            creationflags=subprocess.CREATE_NO_WINDOW)
        record = dict(name=name, command=[str(args.binary), '--json', *map(str, command)],
            exitCode=result.returncode, stdout=result.stdout.decode('utf-8', 'replace'), stderr=result.stderr.decode('utf-8', 'replace'))
        operations.append(record)
        with gzip.open(args.output / 'operations.json.gz', 'wb') as stream:
            stream.write(json.dumps(operations, indent=2).encode())
        if ok:
            assert result.returncode == 0, record
            return json.loads(record['stdout'])
        assert result.returncode != 0, record
        return record

    def binding(path, name):
        return dict(artifactRef='nine:' + name, path=path.relative_to(args.inputs).as_posix(), digest='sha256:' + sha(path))

    def jena(name, data, definition, operation):
        request = json.loads((args.inputs / 'fixtures/gufo-interoperability/shacl-sparql/requests/001-endurant-types-shacl.json').read_bytes())
        request.update(requestRef='nine:' + name, operation=operation, data=binding(data, name),
            definition=binding(definition, name + '-definition'), storePath=(temp / (name + '-store')).relative_to(args.inputs).as_posix())
        path = temp / (name + '-request.json'); write(path, request)
        report = cli(name, ['gufo-shacl-sparql', path])
        write(args.output / (name + '-report.json'), report)
        assert report['receipt']['actualStandardsExecution'] is True
        assert report['persistence']['reloadVerified'] and report['persistence']['roundTripEqual']
        return report['result']

    def owl(name, data, conclusion=None):
        request = dict(schemaVersion='ontograph.full-owl-request.v1', requestRef='nine:' + name,
            operation='entailment' if conclusion else 'consistency', premise=binding(data, name),
            conclusion=None if conclusion is None else binding(conclusion, name + '-claim'), classIri=None,
            imports=[], limits=dict(timeoutMs=30000, memoryLimitMib=512, maxStdoutBytes=1048576,
                maxStderrBytes=262144, networkPolicy='offline-mapped-imports'))
        path = temp / (name + '-owl-request.json'); write(path, request)
        report = cli(name, ['gufo-full-owl-reason', path])
        write(args.output / (name + '-report.json'), report)
        assert report['executionHealth'] == 'completed' and report['result']['status'] == 'executed'
        return report['result']

    workspace = temp / 'workspace'
    cli('workspace-init', ['init', workspace, 'fixtures/canonical/assertion-evidence-thin-slice.json'])
    canonical = workspace / 'data/canonical.json'
    canonical_before = sha(canonical)
    cases = []
    selected = [(i, row) for i, row in enumerate(expected['cases'], 1) if args.case is None or args.case == i]
    for index, oracle in selected:
        prefix = f'c{index:02d}'
        directory = temp / prefix; directory.mkdir()
        retained = args.output / prefix; retained.mkdir()
        try:
            source = args.inputs / oracle['source']['fixturePath']
            assert 'sha256:' + sha(source) == oracle['source']['digest']
            assert source.stat().st_size == oracle['source']['bytes']
            (retained / 'executed-source.ttl').write_bytes(source.read_bytes())
            write(retained / 'oracle.json', oracle)
            request = directory / 'admit.json'
            write(request, dict(source=source.read_bytes().decode('utf-8'), expectedDigest=oracle['source']['digest']))
            report = cli(prefix+'-admit', ['gufo-source-admit', request])
            write(retained / 'admission.json', report)
            candidate = directory / 'candidate.json'; write(candidate, report['candidate'])
            write(retained / 'candidate.json', report['candidate'])
            candidate_before = sha(candidate)
            reload_request = directory / 'reload.json'; write(reload_request, dict(candidate=json.loads(candidate.read_bytes()), expectedCandidateDigest=report['candidateDigest']))
            reloaded = cli(prefix+'-reload', ['gufo-source-admit', reload_request])
            reimported = cli(prefix+'-reimport', ['gufo-source-admit', request])
            assert report == reloaded == reimported
            assert report['candidate']['sourceAssertionCount'] == oracle['tripleCount']
            data = directory / 'generated.ttl'; data.write_bytes(report['graph'].encode())
            reload_data = directory / 'reloaded.ttl'; reload_data.write_bytes(reloaded['graph'].encode())
            shapes = directory / 'generated-shapes.ttl'; shapes.write_bytes(report['shapes'].encode())
            for path in (data, shapes): (retained / path.name).write_bytes(path.read_bytes())
            graph = Graph().parse(data, format='turtle'); original = Graph().parse(source, format='turtle')
            assert len(graph) == oracle['tripleCount'] and isomorphic(original, graph)
            assert isomorphic(graph, Graph().parse(reload_data, format='turtle'))
            assert report['graphDigest'] == 'sha256:' + sha(data)
            assert report['shapesDigest'] == 'sha256:' + sha(shapes)
            # Offline import materialization retains every generated assertion except the one mapped remote import.
            materialized = Graph()
            removed = []
            for triple in graph:
                if triple[1] == OWL.imports: removed.append([str(v) for v in triple])
                else: materialized.add(triple)
            assert len(removed) == 1 and removed[0][2] == 'https://purl.org/nemo/gufo#'
            ontology = args.inputs / 'fixtures/gufo-interoperability/owl-reasoner/external-corpus/sources/gufo-f412254.ttl'
            assert sha(ontology) == '0eb67c085a9ebf3bd559b1f19ca32cc9be1f4fd2d7f604eb7dfd92843f8dcc66'
            materialized.parse(ontology, format='turtle')
            combined = directory / 'offline-owl.ttl'; materialized.serialize(combined, format='nt', encoding='utf-8')
            (retained / combined.name).write_bytes(combined.read_bytes())
            write(retained / 'offline-import-receipt.json', dict(sourceDigest=oracle['source']['digest'],generatedDigest=report['graphDigest'],removedImport=removed,ontologyDigest='sha256:'+sha(ontology),materializedDigest='sha256:'+sha(combined),allOntologyAxiomsPreserved=True))
            consistency = owl(prefix+'-consistency', combined)
            assert consistency['consistent'] is oracle['owlConsistent']
            entailments=[]
            for ci, claim in enumerate(oracle['entailments']):
                s,p,o = [claim[k] for k in ('subject','predicate','object')]
                declarations=''
                if p == str(RDF.type): declarations=f'<{o}> <{RDF.type}> <{OWL.Class}> .\n'
                elif p == str(OWL.disjointWith): declarations=f'<{s}> <{RDF.type}> <{OWL.Class}> .\n<{o}> <{RDF.type}> <{OWL.Class}> .\n'
                elif p != str(OWL.sameAs): declarations=f'<{p}> <{RDF.type}> <{OWL.ObjectProperty}> .\n'
                conclusion=directory/f'claim-{ci}.ttl'; conclusion.write_text(declarations+f'<{s}> <{p}> <{o}> .\n',encoding='utf-8',newline='\n')
                answer=owl(prefix+f'-claim-{ci}',combined,conclusion)
                assert answer['entailed'] is claim['expected'], (claim, answer)
                entailments.append(dict(claim=claim,result=answer))
            coverage=jena(prefix+'-coverage',data,shapes,'shacl-validation')
            assert coverage['conforms'] is True
            upstream_shapes=args.inputs/'fixtures/gufo-interoperability/shacl-sparql/sources/gufoshapes.ttl'
            assert sha(upstream_shapes)=='b3422e20ba0babf1ec76988c42226bfab144c2be4525fada2e4a347bcc246dc3'
            upstream=jena(prefix+'-shacl',data,upstream_shapes,'shacl-validation')
            assert upstream['conforms'] is oracle['shaclConforms']
            keys=('focusNode','constraintComponent','resultPath','severity','value','message')
            signatures=[{k:row[k] for k in keys} for row in upstream['shaclResults']]
            signatures.sort(key=lambda r:json.dumps(r,sort_keys=True))
            assert signatures == oracle['shaclSignatures'], (oracle['caseRef'],signatures,oracle['shaclSignatures'])
            answers=[]
            for qi, query in enumerate(oracle['queries']):
                definition=directory/f'query-{qi}.rq'; definition.write_text(query['text']+'\n',encoding='utf-8',newline='\n')
                before=jena(prefix+f'-q{qi}',data,definition,'sparql-select')
                after=jena(prefix+f'-q{qi}-reload',reload_data,definition,'sparql-select')
                assert before['variables'] == after['variables'] == query['variables']
                assert before['rows'] == after['rows'] == query['rows'], (prefix,query['name'],before['rows'],query['rows'])
                answers.append(dict(name=query['name'],variables=before['variables'],rows=before['rows']))
            adverse=directory/'drift.json'; write(adverse,dict(source=source.read_bytes().decode('utf-8')+'\n',expectedDigest=oracle['source']['digest']))
            failure=cli(prefix+'-pin-drift',['gufo-source-admit',adverse],ok=False)
            assert 'GUFO-ADMISSION-PIN' in failure['stderr']
            tampered=json.loads(candidate.read_bytes()); tampered['sourceBytes'] += 1
            adverse_candidate=directory/'candidate-drift.json'; write(adverse_candidate,dict(candidate=tampered,expectedCandidateDigest=report['candidateDigest']))
            rejected=cli(prefix+'-candidate-drift',['gufo-source-admit',adverse_candidate],ok=False)
            assert 'GUFO-ADMISSION-CANDIDATE-PIN' in rejected['stderr']
            assert sha(candidate)==candidate_before and sha(canonical)==canonical_before
            result=dict(caseRef=oracle['caseRef'],status='passed',completeSourceIsomorphic=True,
                sourceAssertions=oracle['tripleCount'],candidate=args.source_commit,binarySha256=sha(args.binary),
                deterministicReloadReimport=True,sourceCanonicalNonmutation=True,owl=consistency,
                entailments=entailments,generatedShacl=coverage,upstreamShacl=upstream,
                queries=answers,independentReview='pending',limits=report['semanticLimits'])
            write(retained/'verification.json',result); cases.append(result)
        except BaseException as error:
            result=dict(caseRef=oracle['caseRef'],status='failed',exception=repr(error),operations=len(operations))
            write(retained/'failure.json',result); cases.append(result)
    assert protected == {p.relative_to(args.inputs).as_posix():sha(p) for folder in ('fixtures','schemas','specs') for p in (args.inputs/folder).rglob('*') if p.is_file()}
    passed=sum(row['status']=='passed' for row in cases)
    status='passed' if passed==len(selected) else 'failed'
    write(args.output/'verification.json',dict(schemaVersion='ontograph.gufo.nine-suite-evidence.v1',status=status,
        candidate=args.source_commit,binarySha256=sha(args.binary),oracleSha256=sha(expectations_path),
        runnerSha256=sha(Path(__file__)),operations=len(operations),cases=cases,
        passedCases=passed, installedRuns=1,
        counters=dict(implemented=passed,fullyDemonstrated=0,independentlyReviewed=0,denominator=9),
        selectedCases=len(selected),toolIdentities=dict(javaSha256=sha(args.java),jenaJavaSha256=sha(args.jena_java),
            owlFiles={p.relative_to(args.tools).as_posix():sha(p) for p in args.tools.rglob('*') if p.is_file()},
            jenaFiles={p.name:sha(p) for p in (args.jena_home/'lib').glob('*') if p.is_file()})))
    if status!='passed': raise RuntimeError(f'{len(selected)-passed} cases failed; all observations retained')

if __name__ == '__main__':
    main()
